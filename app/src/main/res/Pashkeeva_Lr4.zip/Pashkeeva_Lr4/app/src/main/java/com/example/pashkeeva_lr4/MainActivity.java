package com.example.pashkeeva_lr4;

import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private TextView headingText;
    private Spinner fontSizeSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        headingText = findViewById(R.id.headingText);
        fontSizeSpinner = findViewById(R.id.fontSizeSpinner);
        ImageButton boldButton = findViewById(R.id.boldButton);
        ImageButton italicButton = findViewById(R.id.italicButton);
        ImageButton clearButton = findViewById(R.id.clearButton);

        // Настройка выпадающего списка для выбора размера шрифта
        String[] fontSizes = {"10", "12", "14", "16", "18", "20", "24", "28", "32"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, fontSizes);
        fontSizeSpinner.setAdapter(adapter);

        // Изменение размера шрифта выделенного текста
        fontSizeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                changeFontSize(Integer.parseInt(fontSizes[position]));
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Обработчики нажатий на кнопки
        boldButton.setOnClickListener(v -> applyTextStyle(Typeface.BOLD));
        italicButton.setOnClickListener(v -> applyTextStyle(Typeface.ITALIC));
        clearButton.setOnClickListener(v -> {
            editText.setText("");
            headingText.setText("Heading");
        });
    }

    // Метод для изменения размера выделенного текста
    private void changeFontSize(int fontSize) {
        int start = editText.getSelectionStart();
        int end = editText.getSelectionEnd();
        if (start == end) return; // Если нет выделенного текста, ничего не делаем

        SpannableStringBuilder ssb = new SpannableStringBuilder(editText.getText());
        ssb.setSpan(new RelativeSizeSpan(fontSize / 14.0f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        editText.setText(ssb);
        editText.setSelection(end);
    }

    // Метод для применения жирного или курсивного стиля к выделенному тексту
    private void applyTextStyle(int style) {
        int start = editText.getSelectionStart();
        int end = editText.getSelectionEnd();
        if (start == end) return;

        Spannable spannable = editText.getText();
        boolean hasStyle = false;

        // Проверка, есть ли уже стиль
        StyleSpan[] spans = spannable.getSpans(start, end, StyleSpan.class);
        for (StyleSpan span : spans) {
            if (span.getStyle() == style) {
                spannable.removeSpan(span);
                hasStyle = true;
            }
        }

        // Если стиль отсутствует, добавляем его
        if (!hasStyle) {
            spannable.setSpan(new StyleSpan(style), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        editText.setText(spannable);
        editText.setSelection(end);
    }
}
